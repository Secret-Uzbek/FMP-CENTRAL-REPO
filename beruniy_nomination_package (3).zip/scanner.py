# scanner.py
# Scans configured prize/award pages and RSS feeds, extracts basic metadata,
# logs changes to prizes_catalog.csv, and creates nomination draft folders.
#
# Designed to be run in GitHub Actions (or any CI). Does HTTP requests;
# requires INTERNET access at runtime (Actions has internet).
#
# Secrets / environment variables expected:
# - GITHUB_TOKEN (automatically provided in Actions) or PERSONAL_ACCESS_TOKEN (for pushing)
# - REPO (owner/repo)
# - NOMINATOR_NAME, NOMINATOR_CONTACT (used when generating draft emails)
#
import os, csv, re, hashlib, json, datetime, sys
from urllib.parse import urlparse
try:
    import requests
    from bs4 import BeautifulSoup
except Exception as e:
    print('Missing dependencies: requests and bs4 are required. See README for installation.')
    raise

CONFIG_PATH = 'scan_config.json'
CATALOG_CSV = 'prizes_catalog.csv'
OUT_DIR = 'scans'

def normalize_text(s):
    return re.sub(r'\s+', ' ', (s or '').strip())

def fetch_url(url, timeout=20):
    headers = {'User-Agent': 'AIUZ-Prize-Scanner/1.0 (+https://github.com/Secret-Uzbek)'} 
    r = requests.get(url, headers=headers, timeout=timeout)
    r.raise_for_status()
    return r.text

def parse_generic_page(html, url):
    from bs4 import BeautifulSoup
    soup = BeautifulSoup(html, 'html.parser')
    title = soup.title.string.strip() if soup.title else ''
    # try common meta tags
    description = ''
    if soup.find('meta', attrs={'name':'description'}):
        description = soup.find('meta', attrs={'name':'description'}).get('content','')
    elif soup.find('meta', attrs={'property':'og:description'}):
        description = soup.find('meta', attrs={'property':'og:description'}).get('content','')
    # find potential deadline heuristics
    text = soup.get_text(separator=' ', strip=True)
    # naive date search (YYYY or dates like 30 June 2025)
    dates = re.findall(r'\b(?:\d{1,2} [A-Za-z]+ \d{4}|\d{4})\b', text)
    date_hint = dates[0] if dates else ''
    return {
        'url': url,
        'title': normalize_text(title),
        'description': normalize_text(description),
        'date_hint': date_hint
    }

def scan_one(source):
    url = source.get('url')
    kind = source.get('type', 'page')
    try:
        html = fetch_url(url)
        meta = parse_generic_page(html, url)
        meta['source_name'] = source.get('name', 'unknown')
        meta['type'] = kind
        return meta
    except Exception as e:
        return {'url': url, 'error': str(e), 'source_name': source.get('name','unknown')}

def load_config():
    if not os.path.exists(CONFIG_PATH):
        raise FileNotFoundError('Config not found: ' + CONFIG_PATH)
    with open(CONFIG_PATH, 'r', encoding='utf-8') as f:
        return json.load(f)

def hash_meta(m):
    h = hashlib.sha256(json.dumps(m, sort_keys=True).encode('utf-8')).hexdigest()
    return h

def ensure_out():
    os.makedirs(OUT_DIR, exist_ok=True)

def write_catalog(rows):
    keys = ['slug','title','url','source_name','type','description','date_hint','last_seen','status','hash','notes']
    write_header = not os.path.exists(CATALOG_CSV)
    with open(CATALOG_CSV, 'a', newline='', encoding='utf-8') as f:
        writer = csv.DictWriter(f, fieldnames=keys)
        if write_header:
            writer.writeheader()
        for r in rows:
            writer.writerow(r)

def load_existing_catalog():
    import csv, os
    if not os.path.exists(CATALOG_CSV):
        return {}
    out = {}
    with open(CATALOG_CSV, 'r', encoding='utf-8') as f:
        reader = csv.DictReader(f)
        for row in reader:
            out[row.get('url')] = row
    return out

def slugify(url):
    p = urlparse(url)
    s = (p.netloc + p.path).strip('/').replace('/', '-').replace('.', '-')
    s = re.sub(r'[^a-zA-Z0-9-_]', '-', s)
    return s[:120]

def main():
    cfg = load_config()
    ensure_out()
    sources = cfg.get('sources', [])
    existing = load_existing_catalog()
    new_rows = []
    for s in sources:
        meta = scan_one(s)
        now = datetime.datetime.utcnow().isoformat() + 'Z'
        if meta.get('error'):
            row = {
                'slug': slugify(meta.get('url','')),
                'title': '',
                'url': meta.get('url',''),
                'source_name': meta.get('source_name',''),
                'type': meta.get('type','page'),
                'description': '',
                'date_hint': '',
                'last_seen': now,
                'status': 'error:'+meta.get('error',''),
                'hash': '',
                'notes': ''
            }
        else:
            h = hash_meta(meta)
            prev = existing.get(meta['url'])
            status = 'new' if not prev or prev.get('hash')!=h else 'unchanged'
            row = {
                'slug': slugify(meta.get('url','')),
                'title': meta.get('title',''),
                'url': meta.get('url',''),
                'source_name': meta.get('source_name',''),
                'type': meta.get('type','page'),
                'description': meta.get('description',''),
                'date_hint': meta.get('date_hint',''),
                'last_seen': now,
                'status': status,
                'hash': h,
                'notes': ''
            }
        new_rows.append(row)
        # write a simple draft nomination folder for new items
        if row['status'] == 'new':
            folder = os.path.join(OUT_DIR, row['slug'])
            os.makedirs(folder, exist_ok=True)
            with open(os.path.join(folder, 'README.md'), 'w', encoding='utf-8') as rf:
                rf.write('# Draft nomination for: ' + (row['title'] or row['url']) + '\n')
                rf.write('\nSource: ' + row['url'] + '\n')
                rf.write('\nDetected date hint: ' + row.get('date_hint','') + '\n')
                rf.write('\nNext steps: attach executive summary, CVs, letters of support.\n')
    write_catalog(new_rows)
    print('Scan completed. Results appended to', CATALOG_CSV)

if __name__ == '__main__':
    main()
