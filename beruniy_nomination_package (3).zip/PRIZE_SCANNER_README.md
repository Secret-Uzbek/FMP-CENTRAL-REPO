Prize Scanner Implementation - README
-----------------------------------
Purpose:
- Automatically scan configured prize/award pages and RSS feeds for calls relevant to AI, ethics, and research.
- Append findings to prizes_catalog.csv and create draft nomination folders in /scans/<slug>/README.md.
- If changes are detected, open a pull request to the repo with updated catalog and drafts.

Deployment steps (quick):
1. Place scanner.py and scan_config.json in the repository root.
2. Add the GitHub Actions workflow file at .github/workflows/prize_scanner.yml
3. Commit and push to main.
4. Configure repository secrets (Settings -> Secrets):
   - NOMINATOR_NAME (optional)
   - NOMINATOR_CONTACT (optional)
   - GITHUB_TOKEN (Actions provides this automatically; no need to add)
5. Ensure Actions are enabled for the repository. The workflow runs weekly by default.
6. Review created PRs and merge when appropriate.

Notes and security:
- The action uses the provided GITHUB_TOKEN to push branches and create PRs; its permissions may be limited by the repository settings.
- For pushing directly to main or more powerful operations, create a Personal Access Token with repo scope and store it as a secret (PERSONAL_ACCESS_TOKEN) and adapt the workflow.
- The scanner performs HTTP requests; respect robots.txt and Terms of Service of monitored sites. Do not overload servers.

Extensibility:
- Add new seed sources to scan_config.json. You can include RSS feed URLs and specific nomination form URLs.
- Improve parsing: implement site-specific scrapers (e.g., UNESCO call pages often have structured content).
- Use third-party event/award APIs (EventRegistry, Google Custom Search) for broader discovery (requires API keys).
