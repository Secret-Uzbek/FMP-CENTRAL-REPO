Branch: beruniy_nomination_2027
Purpose: Store frozen nomination-ready materials for UNESCO Beruniy Prize (and analogous awards).
Do not modify files here without a formal revision and update of versions. Maintain provenance and record all changes in HISTORY.md.
