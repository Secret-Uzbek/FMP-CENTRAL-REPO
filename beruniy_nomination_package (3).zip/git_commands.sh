# Git commands to create branch and add nomination package
git checkout -b beruniy_nomination_2027
mkdir -p nomination/beruniy-2027
# copy files into nomination/beruniy-2027 then:
git add nomination/beruniy-2027/*
git commit -m "chore(nomination): add beruniy nomination package v1 (freeze)"
git push origin beruniy_nomination_2027
